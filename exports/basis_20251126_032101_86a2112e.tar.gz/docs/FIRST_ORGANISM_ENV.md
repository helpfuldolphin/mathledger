# First Organism: Hardened Test Environment

This guide explains how to set up the secure, hardened environment for integration testing. This setup enforces strict security practices (no default passwords, explicit allow-lists) to match production-grade expectations.

## 1. Configuration File

The configuration is defined in `.env.first_organism`. This file contains:
- Strong, local passwords for Postgres and Redis.
- Explicit CORS allowed origins.
- Rate limits tuned for high-volume testing.
- The `DATABASE_URL` and `REDIS_URL` pre-configured for **local host** access (e.g., running tests via `pytest`).

## 2. Spin Up Infrastructure

Use Docker Compose to start the backing services (Postgres, Redis) using the hardened configuration.

```bash
# Start Postgres and Redis using the hardened credentials
docker-compose --env-file .env.first_organism up -d postgres redis
```

*Note: The `docker-compose.yml` is configured to construct the internal container-to-container connection strings automatically using the variables from the env file.*

Wait for the services to be healthy:
```bash
docker-compose ps
```

## 3. Running Integration Tests (Local)

To run the tests on your host machine (outside Docker), you must export the environment variables so the test runner and application runtime can authenticate.

### Linux / macOS (Bash)
```bash
# Export variables from the file
export $(grep -v '^#' .env.first_organism | xargs)

# Run the integration tests
pytest test_integration_v05.py
```

### Windows (PowerShell)
```powershell
# Load variables
Get-Content .env.first_organism | Where-Object { $_ -match '=' -and $_ -notmatch '^#' } | ForEach-Object {
    $k,$v = $_.Split('=',2)
    [Environment]::SetEnvironmentVariable($k, $v, "Process")
}

# Run the integration tests
pytest test_integration_v05.py
```

## 4. Troubleshooting

**"MissingEnvironmentVariable" Error:**
If you see `MissingEnvironmentVariable: Environment variable 'DATABASE_URL' must be set...`, it means the environment variables were not correctly exported to your shell before running the python command.

**Connection Refused:**
Ensure the Docker containers are running and the ports (5432, 6379) are exposed to localhost.
- Check with `docker ps`.

**Authentication Failed:**
Ensure you are using the generated passwords from `.env.first_organism` and not default `postgres`/`postgres` credentials.
