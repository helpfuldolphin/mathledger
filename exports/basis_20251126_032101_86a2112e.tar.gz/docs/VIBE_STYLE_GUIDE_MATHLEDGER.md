# MathLedger Vibe Style Guide (VCP 2.1)

## Core Philosophy
**Vibe:** Financial-grade cryptographic substrate with research-grade clarity.
**Intent:** Every identifier, error message, log line, and docstring must read as if it belongs to a serious, investor-ready research-engineering product.

## 1. Naming Conventions

### Python (General)
- **Modules/Files:** `snake_case` (e.g., `ledger_ingestor.py`, `dual_root.py`).
- **Classes:** `PascalCase` (e.g., `LedgerIngestor`, `DualAttestationMetadata`).
- **Functions/Methods:** `snake_case` (e.g., `compute_composite_root`, `verify_ui_event`).
- **Variables:** `snake_case` (e.g., `attested_run_context`, `proof_hash`).
- **Constants:** `UPPER_CASE` (e.g., `MAX_RETRIES`, `GENESIS_BLOCK_HASH`).

### Specific Terminology
- **Use:** `LedgerIngestor`, `DualAttestationMetadata`, `AttestedRunContext`.
- **Avoid:** `foo`, `bar`, `tmp`, `hack`, `stuff`, `data` (be specific!), `manager` (unless it strictly manages resources).

### Banned Terms
- `TODO`, `WIP` (use issue tracker).
- `hack`, `slop`, `jank`.
- Casual language (`oops`, `my bad`, `fyi`).

## 2. Logging and Error Messages

### Policy
- **No jokes, no cutesy phrases.**
- **Explicit statements of cause and remediation.**
- **Alignment with proof-or-abstain:** Use `ABSTAIN:` prefix where the system intentionally declines to process or validate something due to safety/integrity concerns.

### Format
- **Standard Info:** `[COMPONENT] Action completed (details=...)`
- **Error:** `[ERROR] <Component>: <Failure Reason>. Remediation: <Action>.`
- **Abstain:** `[ABSTAIN] <Component>: <Reason>.`

### Examples
- **Bad:** `print("oops, failed to verify")`
- **Good:** `logger.error("DualRootVerifier: Hash mismatch in block verification. Remediation: Check local ledger integrity.")`
- **Bad:** `print("skipping this one lol")`
- **Good:** `logger.info("[ABSTAIN] RFLRunner: Candidate failed complexity gate. Skipping promotion.")`

## 3. Documentation Tone

### Docstrings
- **Mandatory** for all core modules and public functions.
- **Tone:** Technical, crisp, objective.
- **References:** Cross-link to specific sections of the MathLedger whitepaper where applicable.
    - Example: `See MathLedger whitepaper §4.2 (Dual Root Attestation).`

### External Docs
- Maintain a professional, "investor-grade" tone.
- Focus on architecture, security properties, and mathematical correctness.

## 4. Implementation

### Vibe Check Tool
Run `make vibe-check` (or `python tools/vibe_check.py`) to enforce these rules.
The tool checks for:
- Banned patterns (`TODO`, `hack`, etc.).
- Missing docstrings in core files.
- Naming violations (where feasible).
