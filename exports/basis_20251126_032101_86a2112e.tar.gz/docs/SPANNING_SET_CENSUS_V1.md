# Spanning Set Census V1

**Date:** November 25, 2025
**Cartographer:** Gemini CLI
**Scope:** `mathledger/` local codebase

## 1. Executive Summary

The census has mapped the entire spanning set of the `mathledger` repository. The current state reveals a heavy metabolic load of experimental and supporting structures surrounding the core nucleus.

| Category | Files | LOC | Share (LOC) |
| :--- | :--- | :--- | :--- |
| **Core** | 291 | ~45.6k | 24.7% |
| **Supporting** | 378 | ~82.2k | 44.6% |
| **Experimental** | 182 | ~56.2k | 30.5% |
| **Archive/Obsolete** | 6 | ~0.3k | <0.1% |
| **Total** | **857** | **~184.3k** | **100%** |

*Note: LOC counts include whitespace/comments.*

## 2. Classification Breakdown

### Core (The Organism)
Must survive into the minimal basis.
- **`basis/`**: The primary nucleus (Cursor O's basis). Contains `attestation`, `core`, `crypto`, `curriculum`, `ledger`, `logic`.
- **`ledger/`**: Legacy ledger ingestion and event handling.
- **`derivation/`**: Pipeline logic.
- **`rfl/`**: Recursive Feedback Loop runner and config.
- **`substrate/`**: Lean/Logic interface.
- **`attestation/`, `normalization/`, `metrics/`**: Core system components.
- **`backend/`, `services/`, `interface/`, `api/`, `cli/`**: Application layer components.
- **`apps/`, `ui/`**: Frontend implementations.

### Supporting (The Scaffold)
Infrastructure, operations, and verification tools.
- **`ops/`, `infra/`, `config/`**: Deployment and operational scripts.
- **`tests/`, `testing/`, `.quarantine/`**: Verification suite.
- **`migrations/`**: Database schema evolution.
- **`tools/`, `scripts/`**: Helper utilities.
- **`ledgerctl.py`, `run_*.py`, `sanity.ps1`**: Operational entry points.
- **`docs/`, `reports/`, `logs/`**: Documentation and artifacts.

### Experimental (The Residue)
High-risk zones, potential future features, or abandoned attempts.
- **`*.patch`, `*.diff`**: Loose patch files (candidates for deletion or merging).
- **`test_*.py` (Root)**: Unorganized test scripts.
- **`_fail_*.txt`**: Failure logs.
- **`bootstrap_*.py`**: Experimental bootstrapping scripts.

## 3. Critical Analysis

The ratio of **Core** to **Non-Core** code is approximately **1:3**. This suggests a system in heavy flux or one carrying significant historical debt.

**Key Observations:**
1.  **High Experimental Load**: ~30% of the codebase is classified as experimental. This includes many root-level patch files and ad-hoc scripts which clutter the workspace and pose a confusion risk.
2.  **Basis Nucleus**: The `basis/` directory appears to be the intended clean slate or "refined" core.
3.  **Scattered Tests**: While `tests/` exists, there are many `test_*.py` files at the root, indicating a drift in testing discipline.

## 4. Basis Candidate Proposal

The **Minimal Basis Candidate** (the seed for the next phase) should be formed around the `basis/` directory, augmented by select modules from legacy core components.

**Proposed Nucleus:**
- `basis/` (Full inclusion)
- `substrate/` (For rigorous definitions)
- `rfl/` (For the feedback loop)
- `ledger/` (Selected logic for continuity)

**Quarantine Action Items:**
- Move root-level `test_*.py` files to `tests/` or `archive/`.
- Archive `*.patch` and `*.diff` files to `archive/artifacts/`.
- Consolidate root-level `bootstrap_*.py` and other scratch scripts into `ops/scratch/` or `tools/`.
