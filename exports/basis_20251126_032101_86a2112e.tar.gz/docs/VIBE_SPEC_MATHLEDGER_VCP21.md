# Vibe Specification Document: MathLedger VCP 2.1
**Controller:** Global Orchestrator  
**Status:** Active  
**Date:** 2025-11-25

## 1. Vibe & Intent
**Vibe:** Ultra-clean, investor-grade, cryptographically precise, abstention-first. No slop.
**Intent:** Transform `mathledger/` from a chaotic spanning set into a precision substrate that can spawn a minimal `basis/` (eventually a separate repo).

## 2. Core Constraints

### 2.1. Determinism & Randomness
*   **No Hidden Randomness:** `random` and `os.urandom` are forbidden in core logic. All entropy must be injected via explicit seed parameters or derived from the ledger state.
*   **Explicit Seeding:** Any stochastic process (e.g., in RFL exploration) must take a seed derived from the previous block hash $H_{t-1}$.

### 2.2. Failure Semantics
*   **Proof-or-Abstain:** Functions never return "best effort" wrong answers. They return a Proof/Result or they Abstain (raise/return Error).
*   **No Silent Failures:** Catch-all `except Exception: pass` is strictly forbidden. All errors must be logged with context or propagated.

### 2.3. Data Canonization
*   **RFC 8785:** All JSON artifacts that are hashed or persisted MUST be canonicalized using RFC 8785 (JCS).
*   **Immutability:** Once a ledger entry is finalized, it is immutable.

### 2.4. Dual Attestation (Rₜ, Uₜ, Hₜ)
*   **Structure:** Every state transition $t$ yields a tuple $(R_t, U_t, H_t)$:
    *   $R_t$: Root of Reasoning (mathematical truths, derivations).
    *   $U_t$: Root of UI/UX (user interactions, views).
    *   $H_t$: Unified History hash = $H(R_t || U_t || H_{t-1})$.
*   **Verification:** Clients must be able to verify $H_t$ locally.

### 2.5. Operational Continuity
*   **Shimmed Evolution:** Changes must not break `uv run`, `pytest`, or the API server. Use adapter patterns if substantial API changes are needed.

## 3. Coding Style & Conventions
*   **Type Hinting:** 100% coverage for core modules (`backend/`).
*   **Imports:** Absolute imports preferred. No circular dependencies.
*   **Comments:** "Why", not "What". Docstrings for all public interfaces.
*   **Formatting:** Adhere to project `.editorconfig` and `black`/`ruff` configurations.

## 4. Refactor Priorities
1.  **Sanitize Substrate:** Ensure `backend/worker.py` and `backend/logic` are deterministic.
2.  **Canonicalize Ledger:** Enforce RFC 8785 in `backend/ledger`.
3.  **Activate Dual Attestation:** Wire `backend/crypto/dual_root.py` into the main loop.
4.  **Clean API:** Standardize `backend/orchestrator` to use schema-validated inputs/outputs.

## 5. Integration Standards (First Organism Loop)
*   **The Loop:** Substrate -> Derivation -> Ledger -> RFL -> Substrate.
*   **Verification:** The entire loop must run deterministically from a genesis seed.
*   **Tests:** Unit tests for components, Integration tests for the full loop.
