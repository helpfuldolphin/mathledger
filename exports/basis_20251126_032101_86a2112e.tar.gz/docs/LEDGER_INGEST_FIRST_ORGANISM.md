# Ledger Ingestion Contract for First Organism

## Overview

The "First Organism" requires strict adherence to the monotone ledger, Merkle root over proofs, dual-root attestation, and block metadata semantics described in the whitepaper. This document defines the contract for ingestion and block sealing.

## Core Semantics

### 1. Monotone Ledger & Deduplication
- **Statements**: Deduplicated by their canonical hash (SHA-256 of normalized content).
- **Proofs**: Deduplicated by `(statement_id, prover, proof_hash)`.
- **Atomicity**: Block and linkage rows must be written in a single transaction.

### 2. Dual-Root Attestation
Every block $B_t$ is sealed with a composite root $H_t$ derived from two domain-separated Merkle trees:

1.  **Reasoning Root ($R_t$)**:
    *   Computed from the sequence of proofs in the block.
    *   $R_t = \text{MerkleRoot}(\{P_1, P_2, ..., P_n\})$

2.  **UI Root ($U_t$)**:
    *   Computed from the sequence of UI events (interactions) since the last block.
    *   $U_t = \text{MerkleRoot}(\{E_1, E_2, ..., E_m\})$

3.  **Composite Root ($H_t$)**:
    *   Cryptographically binds the reasoning and UI roots.
    *   $H_t = \text{SHA256}(R_t \parallel U_t)$

### 3. Block Metadata
Each sealed block must contain:
- `block_id`: Unique database identifier.
- `sequence` (or `block_number`): Strictly increasing integer.
- `timestamp`: Sealing time.
- `reasoning_root`: $R_t$
- `ui_root`: $U_t$
- `composite_root`: $H_t$

## Helper Interface

For testing and verification, the following helper is exposed:

```python
@dataclass
class SealedBlock:
    reasoning_root: str
    ui_root: str
    composite_root: str
    block_id: Optional[int]
    sequence: int
    timestamp: int

def ingest_and_seal_for_first_organism(result: List[Dict], ui_events: List[Any]) -> SealedBlock:
    """
    Ingests proofs and UI events, returning the sealed block with dual roots.
    """
```
