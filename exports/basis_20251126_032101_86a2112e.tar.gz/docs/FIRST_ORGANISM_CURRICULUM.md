---
title: FIRST ORGANISM Curriculum Slice
---

# First Organism Curriculum Slice

**Author**: Cursor G — Curriculum Gatekeeper  
**Purpose**: Provide a traceable, gate-guarded curriculum entry for the First Organism integration test (PL → FOL → Equational → LIA ladder).

## Ladder Context

The MathLedger ladder progresses:

1. **PL (Propositional Logic)** – atoms/depth slices covering core propositional proof patterns.  
2. **FOL (First-Order Logic)** – quantifiers, predicates, and reflexive reasoning; the proof space begins to require instantiation and background knowledge.  
3. **Equational** – equality-rich statements where rewriting is dominant.  
4. **Arithmetic (QF-LIA/LRA)** – numeric domains with linear integer/real arithmetic; the hardest slices rely on numeric solvers and heavy search.

Each production slice enforces four gate families (coverage, abstention, velocity, caps) backed by canonical telemetry. The First Organism test cannot yet perform the full ladder, so it leverages a bespoke “trial” slice that sits within this hierarchy without skipping any gate.

## make_first_organism_slice()

`make_first_organism_slice()` returns a `CurriculumSlice` with:

- **Coverage gate**: high CI lower bound (≥0.915) that will fail given a single small derivation run.  
- **Abstention gate**: rate bound (≤18 %) and mass limit (≤640) that the test can satisfy even while the verifier abstains.  
- **Velocity gate**: modest proofs/hour (≥160 pph) with a relaxed CV (≤0.10) to let the test progress in a noisy environment.  
- **Caps gate**: ensures enough attempt mass (>2400), runtime (>20 min), and manageable backlog (<36 %) before ratcheting.

These thresholds intentionally permit **exactly one trial run**: the slice passes every gate except coverage, proving the gate engine was consulted but halting advancement until real coverage accumulates.

## build_first_organism_metrics()

This helper synthesizes a normalized metrics payload whose:

- Coverage CI sits below the requirement (failure).  
- Abstention rate/mass, velocity, backlog, and runtime all satisfy the gate to keep focus on the coverage failure.  
- Provenance contains an attestation hash, which is later reflected in the dual-root handshake (`Hₜ`) consumed by the RFL runner.

The integration test asserts the resulting `GateVerdict`:

1. Reports coverage failure with the correct gate reason.  
2. Lists passing entries for abstention, velocity, and caps.  
3. Includes an audit payload containing the attestation hash that must match the ledger/dual-root view later in the closed loop.

## Alignment with the Ladder

This slice is acceptable because it:

- Lives at the base of the ladder (PL-like depth 5, atoms 4).  
- Honors the same gate disciplines as production slices, so the test can prove the gate-checking plumbing without accelerating the curriculum.  
- Records the failure mode (coverage) that prevents ratcheting, ensuring the ladder stays locked until the organism demonstrates actual statistical coverage in later waves.

Future waves can reuse this canonical slice to bootstrap higher-level integrations once the organism demonstrates reproducible coverage, then graduate to the next slice (FOL) by crafting new presets with higher thresholds.

