# Basis Promotion Blueprint — Wave 1

Status: _pre-integration_ (awaiting `test_first_organism_closed_loop`)

Purpose: track how the canonical `basis/` types and primitives already map onto
the spanning-set services. Once the First Organism integration test is green,
this document becomes the promotion manifest for Cursor P.

---

## Core Value Types

| Basis Type | Spanning-Set Usage | Ready for Promotion? | Notes |
|------------|-------------------|----------------------|-------|
| `basis.core.BlockHeader` / `basis.core.Block` | Constructed in `backend/ledger/blockchain.py` (`seal_block`) and `backend/ledger/blocking.py` (block assembly). Block headers are persisted via `backend/ledger/ingest.py` during finalize/commit. | ✅ Yes | Structures align: deterministic header fields, statement lists, Merkle hash usage. Migration = swap to `basis.ledger.block.seal_block` and `basis.core.Block`. |
| `basis.core.DualAttestation` | Materialised in `backend/crypto/dual_root.py` and propagated through `backend/ledger/blocking.py` → `backend/ledger/ingest.py` (dual-root columns). | ✅ Yes | Current pipeline computes `(reasoning_root, ui_root, composite)` with matching schema. Basis wrapper adds immutable type + validation. |
| `basis.core.CurriculumTier` | Curriculum definitions/gates in `backend/frontier/curriculum.py`, `backend/rfl/config.py`, `backend/rfl/coverage.py`. | ⚠️ Pending integration | The gate logic consumes dict/NamedTuple structures; once First Organism test wires the curriculum gate, we can wrap exported tiers via `basis.curriculum.ladder`. |

---

## Logic Canonicalisation

| Basis Primitive | Spanning-Set Usage | Ready? | Notes |
|-----------------|--------------------|--------|-------|
| `basis.logic.normalize` & friends | Used implicitly via `backend/logic/canon.py` across ingestion, hashing (`backend/crypto/hashing.py`), derivation (`backend/axiom_engine/*`), and metrics. | ✅ Yes | The basis normaliser is a distilled port of `backend/logic/canon.py`. After First Organism passes, consumers can redirect imports to `basis.logic`. |

---

## Cryptographic Hashing, Merkle, Proofs

| Basis Primitive | Spanning-Set Usage | Ready? | Notes |
|-----------------|--------------------|--------|-------|
| `basis.crypto.sha256_hex`, `hash_statement` | Present in `backend/crypto/hashing.py`; used by `backend/ledger/ingest.py`, `backend/ledger/blockchain.py`. | ✅ Yes | Basis mirrors the existing implementation with domain separation. |
| `basis.crypto.merkle_root`, `compute_merkle_proof`, `verify_merkle_proof` | `backend/crypto/hashing.py`, `backend/ledger/blockchain.py`, `backend/crypto/dual_root.py`, `verify_dual_root.py`. | ✅ Yes | Functions are API-compatible; migration just updates import paths. |
| `basis.crypto.reasoning_root`, `ui_root` | `backend/crypto/dual_root.py` calculates roots over proofs/UI events. | ✅ Yes | Implementation is identical; basis adds explicit domain tags for empty streams. |

---

## Ledger Sealing

| Basis Primitive | Spanning-Set Usage | Ready? | Notes |
|-----------------|--------------------|--------|-------|
| `basis.ledger.seal_block`, `block_json` | `backend/ledger/blockchain.py` (seal), `backend/ledger/ingest.py` (persist), `backend/ledger/blocking.py` (assembly). | ✅ Yes | After integration test confirms end-to-end ingest, swap to basis helpers for canonical JSON + sorted statements. |

---

## Dual Attestation

| Basis Primitive | Spanning-Set Usage | Ready? | Notes |
|-----------------|--------------------|--------|-------|
| `basis.attestation.build_attestation`, `verify_attestation` | Legacy functions in `backend/crypto/dual_root.py`, `verify_dual_root.py`, `backend/ledger/blocking.py`. | ✅ Yes | Basis consolidates compute/verify logic; ingestion emits same fields. |

---

## Curriculum Ladder

| Basis Primitive | Spanning-Set Usage | Ready? | Notes |
|-----------------|--------------------|--------|-------|
| `basis.curriculum.CurriculumLadder`, `ladder_from_json` | Curriculum staging in `backend/rfl/config.py`, `backend/frontier/curriculum.py`, artifacts under `artifacts/rfl`. | ⚠️ Awaiting gate wiring | Need First Organism to exercise curriculum gate → RFL runner loop. When test passes, wrap slice definitions using ladder helpers. |

---

## RFL Runner Interfaces

| Basis Concept | Spanning-Set Usage | Ready? | Notes |
|---------------|--------------------|--------|-------|
| Dual-attestation consumption (`DualAttestation`, `Block`) | `backend/rfl/runner.py` reads ledger/attestation rows. | ⚠️ Pending instrumentation | Verify First Organism test surfaces `H_t` / abstention payloads—once confirmed, we can refactor runner inputs to accept basis types. |

---

### Next Steps (triggered once `test_first_organism_closed_loop` passes)

1. Capture evidence from the integration test (logs, persisted records) showing each subsystem consuming the canonical structures.
2. Update this blueprint with concrete assertions/paths from the test run.
3. Draft migration PRs swapping legacy imports (`backend.crypto.hashing`, `backend.ledger.blockchain`, etc.) to `basis.*`.
4. Prepare packaging metadata (`pyproject.toml` entry, README) so Cursor P can promote Wave 1 cleanly.

