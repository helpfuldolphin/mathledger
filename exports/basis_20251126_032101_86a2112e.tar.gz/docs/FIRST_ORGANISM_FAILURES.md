# First Organism Failure Atlas

This document enumerates the failure modes for the First Organism causal chain:
`UI Event → Curriculum Gate → Derivation → Lean → LedgerIngestor → DualRoot → RFL Runner`

## Failure Modes

| Layer | Failure Mode | Trigger Condition | Expected Behavior | Status |
|---|---|---|---|---|
| **UI Event** | `ui_bad_payload` | JSON payload missing `event_id` or `action` | API returns 422 Validation Error | Tested |
| **UI Event** | `ui_db_failure` | Database connection raises exception during insert | API returns 500 Internal Server Error | Tested |
| **Curriculum** | `gate_missing_metrics` | Metrics object is `None` or empty | Gate raises `ValueError` or `AssertionError` | Tested |
| **Curriculum** | `gate_threshold_failure` | `coverage_ci_lower < 0.95` (config threshold) | `gate.passed` is `False` | Tested |
| **Derivation** | `derive_no_statements` | Pipeline exhausted or bounds too tight | `run_step` returns empty list, process handles gracefully | Tested |
| **Derivation** | `derive_normalization_fail` | Statement contains illegal characters | `normalize` raises exception, caught by pipeline | Tested |
| **Lean** | `lean_timeout` | Lean process hangs > timeout | Prover status `timeout`, ingest continues | Tested |
| **Lean** | `lean_crash` | Lean process exits with code 1 | Prover status `error`, ingest continues | Tested |
| **Ledger** | `ingest_schema_mismatch` | `proof_text` exceeds DB column limit | `ingest()` raises `DataError` / `IntegrityError` | Tested |
| **Ledger** | `ingest_dual_root_missing` | `ui_events` is empty for sealed block | `_seal_block` raises `ValueError` | Tested |
| **DualRoot** | `dual_merkle_mismatch` | `composite_root` != `hash(r_t + u_t)` | Validation raises `IntegrityError` | Tested |
| **RFL** | `rfl_missing_ht` | Attestation input missing `composite_root` | Runner raises `ValueError` | Tested |
| **RFL** | `rfl_invalid_payload` | Attestation metadata malformed | Runner raises `KeyError` or `ValidationError` | Tested |

## Testing Strategy

The chaos harness `tests/integration/test_first_organism_failure_modes.py` iterates through these modes, injecting faults via:
1.  **Mocking**: Replacing standard classes (`LedgerIngestor`, `DerivationPipeline`) with `Mock` or `MagicMock`.
2.  **Monkeypatching**: Overriding module-level functions or environment variables.
3.  **Input Injection**: Passing malformed data to valid entry points.

Each test asserts that the system fails *safely* (e.g., explicit error, specific status code, or controlled abstention) rather than crashing or corrupting data.
