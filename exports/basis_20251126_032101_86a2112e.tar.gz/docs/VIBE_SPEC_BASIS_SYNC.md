# Vibe Specification: Basis Synchronization (VSD-SYNC)

**Version:** 1.0  
**Status:** ACTIVE  
**Role:** Basis Synchronization Architect  

## 1. Core Vibe
**Ascetic. Cryptographically Obsessed. Zero-Slop.**

The `basis` repository (`helpfuldolphin/mathledger`) is not a sandbox. It is a **Sealed Vault**. It contains only the minimal, living organism required to bootstrap the MathLedger reality.

- **No Comments** (unless structurally vital).
- **No Dead Code**.
- **No "TODOs"**.
- **No Experimental Branches**.

It is a mathematical object. If `mathledger/` (local) is the noisy factory floor, `basis/` (remote) is the diamond produced at the end of the assembly line.

## 2. Intent
To define a reproducible, auditable, fully deterministic process that promotes vetted modules from the local spanning set (`mathledger/`) to the minimal basis repository.

**The Prime Directive:**
> Changes flow **ONE WAY**: Local Spanning Set -> Promotion Gate -> Basis Repo.
> Direct edits to the Basis Repo are **FORBIDDEN**.

## 3. Constraints

### 3.1 The Immutable Flow
1.  **Source of Truth:** `C:\dev\mathledger` (Local Spanning Set).
2.  **Transformation:** `ops/promote_basis.py` (The Sieve).
3.  **Destination:** `git@github.com:helpfuldolphin/mathledger.git` (The Vault).

### 3.2 The Gates
No promotion shall pass unless:
1.  **First Organism Test Passes:** The minimal viable organism must survive in isolation.
2.  **Determinism Harness Green:** Identical inputs MUST yield identical hashes.
3.  **Security Runtime Green:** No keys in code, no leaked secrets, domain separation enforced.
4.  **Hash Stability:** The source modules must match the `spanning_set_manifest.json` digests.

### 3.3 Artifacts
Every promotion must generate:
- A content-addressed tarball/snapshot.
- A cryptographically signed release note/report.
- A strict git tag (e.g., `v0.1.0-GENOME`).

## 4. The "No Outreach" Rule
As per Strategist VCP 2.1: **No outreach until First Organism passes.**
The Basis Repo remains silent and dark until the organism is proven viable.
