# Hashing & Canonicalization Specification

This document defines the rigorous standard for identity derivation in the MathLedger First Organism. All components must adhere to this specification to ensure cryptographic consensus.

## Core Identity

The identity of any logical statement $s$ is defined as:

$$ \mathrm{hash}(s) = \mathrm{SHA256}(\mathcal{E}(\mathcal{N}(s))) $$ 

Where:
- $\mathcal{N}(s)$ is the **Normalization** function producing a canonical ASCII string.
- $\mathcal{E}(s)$ is the **Encoding** function (ASCII/UTF-8) converting the string to bytes.
- $\mathrm{SHA256}$ is the standard cryptographic hash function.

## 1. Normalization (\mathcal{N})

The normalization process transforms equivalent logical formulas into a single canonical representation. This ensures that `A -> B` and `A → B` (and `(A -> B)`) hash to the same value.

### 1.1 Character Mapping
First, all input characters are mapped to a restricted ASCII alphabet.

| Unicode Source | Canonical ASCII |
| :--- | :--- |
| `→`, `⇒`, `⟹` | `->` |
| `↔`, `⇔` | `<->` |
| `∧`, `⋀` | `/\` |
| `∨`, `⋁` | `\/` |
| `¬`, `￢` | `~` |
| `（`, `⟨` | `(` |
| `）`, `⟩` | `)` |
| (various spaces) | (single space ` `) |

### 1.2 Structure Canonicalization
After mapping, the following rules apply recursively:

1.  **Whitespace**: All whitespace is stripped from the final canonical form.
2.  **Parentheses**: Redundant outer parentheses are removed.
3.  **Negation**: `~A` standardizes negation.
4.  **Conjunction (`/\`)**:
    - Flattened: `(A /\ B) /\ C` becomes `A, B, C`.
    - Sorted: Operands are sorted lexicographically.
    - Deduplicated: Duplicate operands are removed.
    - Joined: `A/\B/\C`.
5.  **Disjunction (`\/`)**:
    - Flattened: `(A \/ B) \/ C` becomes `A, B, C`.
    - Wrapped: Children containing operators are wrapped in parentheses.
    - Sorted: Operands are sorted lexicographically.
    - Deduplicated.
    - Joined: `A\/B\/C`.
6.  **Implication (`->`)**:
    - **Left-Associative**: `A -> B -> C` is interpreted as `(A -> B) -> C`.
    - **Right-Chain Flattening**: The right-hand side is flattened if it is an implication sequence.
    - **Special Case**: `(A -> B) -> C` remains `(A->B)->C`.

## 2. Encoding (\mathcal{E})

The canonical string is encoded using **ASCII**. Since the normalization process guarantees an ASCII-only output, this is equivalent to UTF-8 for the resulting subset.

## 3. Hashing & Domain Separation

To prevent second-preimage attacks (e.g., Merkle tree leaf/node confusion), all hashes are prefixed with a **Domain Separation Tag**.

$$ \mathrm{Hash}_{domain}(x) = \mathrm{SHA256}(\mathrm{Tag}_{domain} || x) $$ 

### Domain Tags

| Domain | Tag (Hex) | Purpose |
| :--- | :--- | :--- |
| **LEAF** | `00` | Merkle Tree Leaf |
| **NODE** | `01` | Merkle Tree Internal Node |
| **STMT** | `02` | Logical Statement Content |
| **BLCK** | `03` | Block Header |
| **FED** | `04` | Federation Namespace |
| **NODE_** | `05` | Node Attestation |
| **DOSSIER** | `06` | Celestial Dossier |
| **ROOT** | `07` | Root Hash |

### 3.1 Statement Hash

$ H_{stmt}(s) = \mathrm{SHA256}(\text{0x02} || \mathcal{E}(\mathcal{N}(s))) $



### 3.2 Proof Artifacts & JSON Canonicalization

Proof artifacts (e.g., JSON objects containing statements, method, proof text) must be canonicalized using **RFC 8785 (JCS)** before hashing.

$ H_{proof}(p) = \mathrm{SHA256}(\text{0xA0} || \text{RFC8785}(p)) $

Note: The domain `0xA0` corresponds to `DOMAIN_REASONING_LEAF`.



### 3.3 Block Hash

$ H_{block}(b) = \mathrm{SHA256}(\text{0x03} || \text{raw\_bytes}(b)) $



### 3.4 Merkle Roots

Merkle trees use specific domain tags for leaves and nodes.



1.  **Leaves**:

    *   **Data Blocks**: $L_i = \mathrm{SHA256}(\text{0x00} || \text{data}_i)$

    *   **Reasoning Leaves**: The system computes the Merkle root of the *proof hashes*.

        The centralized `merkle_root` function receives the proof hashes ($H_{proof}$) and treats them as leaves:

        $ L_{reasoning} = \mathrm{SHA256}(\text{0x00} || H_{proof}) $

2.  **Nodes**: $N = \mathrm{SHA256}(\text{0x01} || \text{LeftChild} || \text{RightChild})$



## Verification



Any implementation MUST verify its correctness against the `tests/test_hash_canonization.py` integration test suite, which traces the exact path from raw string to final ledger hash.


