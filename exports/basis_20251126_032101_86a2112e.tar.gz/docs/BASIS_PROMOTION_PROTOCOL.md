# Basis Promotion Protocol

**Role:** Global Reviewer / Basis Architect  
**Context:** Moving code from Spanning Set (Local) to Basis (Remote/Vault).

## 1. Multi-Agent Decomposition

### Phase 0: Snapshot
**Agent:** `ops/promote_basis.py` (The Archiver)
- **Action:** Bundles `basis/` directory + `minimal_pyproject.toml` + `README` + Spec Docs.
- **Output:** `exports/basis_<hash>.tar.gz`
- **Validation:** Computes SHA-256 of the tarball.

### Phase 1: Validation (The Gates)
**Agent:** `ops/promote_basis.py` (The Sentinel)
- **Action:**
    1.  Runs `tests/first_organism/` (must be GREEN).
    2.  Runs `tests/determinism/` (must be GREEN).
    3.  Checks `spanning_set_manifest.json` against current file hashes.
- **Abort Condition:** ANY failure triggers immediate abort. No partial promotions.

### Phase 2: Materialization
**Agent:** `ops/promote_basis.py` (The Builder)
- **Action:**
    1.  Clones/Updates target repo (`--target-dir`).
    2.  **Wipes** non-whitelisted files in target.
    3.  Unpacks Snapshot into target.
    4.  Verifies integrity (File Count, Hash Match).

### Phase 3: Reporting
**Agent:** `ops/promote_basis.py` (The Scribe)
- **Action:** Generates `basis_promotion_release_notes.md`.
- **Content:**
    - Source Commit Hash.
    - Snapshot Hash.
    - Test Suite Results (Summary + Hashes).
    - Determinism Seed used.

### Phase 4: Tagging & Push
**Agent:** Human Operator (The Keyholder)
- **Action:**
    - Reviews Report.
    - Commits changes in Target.
    - Tags (e.g., `v0.2.0`).
    - Pushes to GitHub.

## 2. Global Reviewer Hooks
Before the "Keyholder" pushes, they must verify:

1.  **Minimality Check:** Does the target contain *only* the basis? (No `tmp/`, no `artifacts/`).
2.  **Hash Identity:** Does `basis_<hash>.tar.gz` match the files currently in the target working tree?
3.  **Green Lights:** Does the log at `ops/logs/basis_promotions.jsonl` show `PASS` for this snapshot hash?

## 3. Reversibility
If a promotion is found to be defective *after* push:
1.  **Do NOT edit remote.**
2.  Revert local change.
3.  Run Promotion Protocol again to generate a reverting commit.
4.  Push.

## 4. Directory Structure (Target)
The Basis Repo should look like this:
```text
/
├── basis/              # The Python Package
├── docs/               # Vibe & Specs
├── tests/              # Minimal test suite to prove life
├── pyproject.toml      # Minimal deps
├── README.md           # The Manifesto
└── LICENSE
```
Anything else is sludge. Remove it.
